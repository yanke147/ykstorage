package IOhomework;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class GradeManager {
    private static final String FILE_PATH = "grades.txt";


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        // 初始化文件
        initializeFile();

        while (running) {
            System.out.println("请选择操作：");
            System.out.println("1. 显示所有成绩记录");
            System.out.println("2. 添加新成绩记录");
            System.out.println("3. 退出");
            System.out.print("请输入选项：");

            int choice = scanner.nextInt();
            scanner.nextLine(); // 消耗换行符

            switch (choice) {
                case 1:
                    displayRecords();
                    break;
                case 2:
                    addNewRecord(scanner);
                    break;
                case 3:
                    running = false;
                    System.out.println("程序已退出。");
                    break;
                default:
                    System.out.println("无效选项，请重新输入。");
            }
        }

        scanner.close();
    }

    /**
     * 初始化文件，写入初始成绩记录。
     */
    private static void initializeFile() {
        String initialData = "学号,姓名,成绩\n" +
                "71108501,张三,80.0\n" +
                "71108502,李四,79.5\n" +
                "71108503,王五,91.0\n" +
                "71108504,赵六,60.0\n" +
                "71108505,宋七,18.6\n";

        try (FileWriter writer = new FileWriter(FILE_PATH)) {
            writer.write(initialData);
            System.out.println("初始数据已写入文件 " + FILE_PATH);
        } catch (IOException e) {
            System.err.println("写入文件时出错: " + e.getMessage());
        }
    }

    
     //从文件中读取成绩记录并显示。
     
    private static void displayRecords() {
        List<String> records = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                records.add(line);
            }
        } catch (IOException e) {
            System.err.println("读取文件时出错: " + e.getMessage());
            return;
        }


        // 打印记录
        for (String record : records) {
            String[] parts = record.split(",");
            if (parts.length == 3) {
                System.out.printf("%s\t%s\t%s%n", parts[0], parts[1], parts[2]);
            }
        }
    }

    /**
     * 添加新的成绩记录到文件。
     *
     * @param scanner 用于读取用户输入
     */
    private static void addNewRecord(Scanner scanner) {
        System.out.print("请输入学号：");
        String id = scanner.nextLine();

        System.out.print("请输入姓名：");
        String name = scanner.nextLine();

        System.out.print("请输入成绩：");
        double score = scanner.nextDouble();
        scanner.nextLine(); // 消耗换行符

        try (FileWriter writer = new FileWriter(FILE_PATH, true)) { // true 表示追加模式
            writer.append(id).append(",").append(name).append(",").append(String.valueOf(score)).append("\n");
            System.out.println("新记录已添加到文件 " + FILE_PATH);
        } catch (IOException e) {
            System.err.println("写入文件时出错: " + e.getMessage());
        }
    }
}