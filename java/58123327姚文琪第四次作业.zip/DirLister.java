package IOhomework;


import java.io.File;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

/**
 * DirLister 类用于列出指定目录下所有具有特定后缀名的文件，并按照用户指定的顺序（升序或降序）
 * 对文件的最后修改时间进行排序。
 * 用户可以从控制台输入目录名、文件后缀名以及排序方式。
 */
public class DirLister {
    private File[] files; // 用于存储符合条件的文件
    private File directory; // 目标目录
    private String extension; // 文件后缀名

    /**
     * 构造方法，初始化 DirLister 对象。
     *
     * @param directory 目标目录
     * @param extension 文件后缀名
     */
    public DirLister(File directory, String extension) {
        this.directory = directory;
        this.extension = extension;
    }

    /**
     * 过滤出给定目录中所有满足条件的文件。
     */
    public void filter() {
        files = directory.listFiles((File file) -> file.getName().endsWith("." + extension));
    }

    /**
     * 根据用户指定的顺序对文件进行排序。
     *
     * @param ascending 是否升序排序
     */
    public void sort(boolean ascending) {
        if (ascending) { // 升序排序
            Arrays.sort(files, Comparator.comparingLong(File::lastModified));
        } else { // 降序排序
            Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        }
    }

    /**
     * 显示所有符合条件的文件。
     */
    public void display() {
        if (files == null || files.length == 0) {
            System.out.println("没有找到符合条件的文件。");
            return;
        }
        for (File file : files) {
            System.out.println("文件名：" + file.getName() + " 最后修改时间：" + file.lastModified());
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("请输入目录名：");
        String dirPath = scanner.nextLine();

        System.out.print("请输入文件后缀名：");
        String extension = scanner.nextLine();

        System.out.print("请输入排序方式（1. 升序 2. 降序）：");
        int sortOption = scanner.nextInt();

        boolean ascending = true;
        if (sortOption == 2) {
            ascending = false;
        }

        DirLister lister = new DirLister(new File(dirPath), extension);
        lister.filter();
        lister.sort(ascending);
        lister.display();

        scanner.close();
    }
}