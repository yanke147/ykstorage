package atm1;
import java.util.HashMap;
import java.util.Map;

public class AccountManager {
    private Map<String, Account> accounts;
    
    public AccountManager() {
        this.accounts = new HashMap<>();
    }
    
    public boolean createAccount(String username, String password) {
        if (accounts.containsKey(username)) {
            return false;  // 用户名不能相同
        }
        accounts.put(username, new Account(username, password, 0.0));
        return true;
    }
    
    public Account validateLogin(String username, String password) {
        if (!accounts.containsKey(username)) {
            return null;  // 用户名不存在的情况
        }
        Account account = accounts.get(username);
        if (account.getPassword().equals(password)) {
            return account;
        } else {
            return null;  // 密码错误的情况
        }
    }

    public Map<String, Account> getAccounts() {
        return accounts;
    }
    public Map<String, Account> getAllAccounts() {
        return accounts;
    }
    
    public void updateAccount(Account account) {
        accounts.put(account.getUsername(), account);
    }
}