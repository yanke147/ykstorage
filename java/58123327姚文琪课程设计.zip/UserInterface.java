package atm1;

import java.util.Scanner;

// UserInterface 类 - 用户界面视图
public class UserInterface {
    private ATMController atmController;
    private Scanner scanner;
    private boolean running;  // 控制程序运行状态
    private boolean inUserMenu;  // 控制是否在用户菜单中
    
    public UserInterface(ATMController atmController) {
        this.atmController = atmController;
        this.scanner = new Scanner(System.in);
        this.running = true;
        this.inUserMenu = false;
    }
    
    // 显示主菜单
    private void displayMainMenu() {
        System.out.println("\n===== ATM 主菜单 =====");
        System.out.println("1. 创建新用户");
        System.out.println("2. 用户登录");
        System.out.println("3. 退出ATM机");
    }
    
    // 显示用户菜单
    private void displayUserMenu() {
        System.out.println("\n===== 用户菜单 =====");
        System.out.println("1. 修改密码");
        System.out.println("2. 查询余额");
        System.out.println("3. 取款");
        System.out.println("4. 存款");
        System.out.println("5. 查询累计利息");
        System.out.println("6. 登出");
    }
    
    // 获取用户选择
    private int getUserChoice(int maxOption) {
        while (true) {
            System.out.print("请输入您的选择: ");
            try {
                int choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 1 && choice <= maxOption) {
                    return choice;
                } else {
                    System.out.println("无效的选择，请重新输入！");
                }
            } catch (NumberFormatException e) {
                System.out.println("无效的输入，请输入数字！");
            }
        }
    }
    
    // 处理主菜单选择
    private void handleMainMenuChoice(int choice) {
        switch (choice) {
            case 1:
                System.out.print("请输入新用户名: ");
                String newUsername = scanner.nextLine();
                System.out.print("请输入新密码: ");
                String newPassword = scanner.nextLine();
                
                if (atmController.register(newUsername, newPassword)) {
                    System.out.println("注册成功！");
                } else {
                    System.out.println("注册失败，用户名可能已存在！");
                }
                break;
                
            case 2:
                System.out.print("请输入用户名: ");
                String username = scanner.nextLine();
                System.out.print("请输入密码: ");
                String password = scanner.nextLine();
                
                if (atmController.login(username, password)) {
                    System.out.println("登录成功！");
                    inUserMenu = true;  // 进入用户菜单
                } else {
                    System.out.println("登录失败，用户名或密码错误！");
                }
                break;
                
            case 3:
                System.out.println("退出ATM机，感谢使用！");
                running = false;  // 设置 running 为 false，退出循环
                break;
                
        }
    }
    
 // 处理用户菜单选择
    private void handleUserMenuChoice(int choice) {
        switch (choice) {
            case 1:
                if (atmController.getCurrentUser() == null) {
                    System.out.println("请先登录！");
                    break;
                }
                System.out.print("请输入旧密码: ");
                String oldPassword = scanner.nextLine();
                System.out.print("请输入新密码: ");
                String newPassword = scanner.nextLine();
                
                if (atmController.changePassword(oldPassword, newPassword)) {
                    System.out.println("密码修改成功！");
                } else {
                    System.out.println("密码修改失败，旧密码错误！");
                }
                break;
                
            case 2:
                atmController.checkBalance();
                break;
                
            case 3:
                System.out.print("请输入取款金额: ");
                try {
                    double amount = Double.parseDouble(scanner.nextLine());
                    atmController.withdraw(amount);
                } catch (NumberFormatException e) {
                    System.out.println("无效的金额！");
                }
                break;
                
            case 4:
                System.out.print("请输入存款金额: ");
                try {
                    double amount = Double.parseDouble(scanner.nextLine());
                    atmController.deposit(amount);
                } catch (NumberFormatException e) {
                    System.out.println("无效的金额！");
                }
                break;
                
            case 5:
                atmController.queryAccumulatedInterest();
                break;
                
            case 6:
                atmController.logout();
                System.out.println("已登出，返回主菜单");
                inUserMenu = false;  // 返回主菜单
                break;
        }
    }
    
    // 启动ATM
    public void start() {
        while (running) {
            if (!inUserMenu) {
                displayMainMenu();
                int choice = getUserChoice(3);
                handleMainMenuChoice(choice);
            } else {
                displayUserMenu();
                int choice = getUserChoice(6);
                handleUserMenuChoice(choice);
            }
        }
        
        scanner.close();
    }
}