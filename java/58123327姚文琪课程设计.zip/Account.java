package atm1;

import java.io.Serializable;

public class Account implements Serializable {
    private String username;
    private String password;
    private double balance;
    private long lastInterestUpdate;  // 记录最后一次利息计算时间
    private double accumulatedInterest;  // 累计利息
    
    public Account(String username, String password, double balance) {
        this.username = username;
        this.password = password;
        this.balance = balance;
        this.lastInterestUpdate = System.currentTimeMillis();  // 初始化为当前时间
        this.accumulatedInterest = 0.0;
    }
    
    // Getters and Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
    public long getLastInterestUpdate() { return lastInterestUpdate; }
    public void setLastInterestUpdate(long lastInterestUpdate) { this.lastInterestUpdate = lastInterestUpdate; }
    public double getAccumulatedInterest() { return accumulatedInterest; }
    public void setAccumulatedInterest(double accumulatedInterest) { this.accumulatedInterest = accumulatedInterest; }

    public double getTotalBalance() {
        return balance + accumulatedInterest;
    }
}