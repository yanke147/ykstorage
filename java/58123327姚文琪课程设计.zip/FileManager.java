package atm1;


import java.io.*;
import java.util.HashMap;
import java.util.Map;

// FileManager 类 - 文件操作辅助类
public class FileManager {
    private static final String ACCOUNTS_FILE = "accounts.txt";
    
    // 保存所有账户到文件
    public static void saveAccounts(AccountManager accountManager) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ACCOUNTS_FILE))) {
            oos.writeObject(accountManager.getAllAccounts());
            System.out.println("账户信息已保存到文件: " + ACCOUNTS_FILE);
        } catch (IOException e) {
            System.err.println("保存账户信息失败: " + e.getMessage());
        }
    }
    
    // 从文件加载所有账户
    public static void loadAccounts(AccountManager accountManager) {
        File file = new File(ACCOUNTS_FILE);
        if (!file.exists()) {
            return;  // 文件不存在，不加载
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ACCOUNTS_FILE))) {
            @SuppressWarnings("unchecked")
            Map<String, Account> loadedAccounts = (Map<String, Account>) ois.readObject();
            accountManager.getAccounts().putAll(loadedAccounts);
            System.out.println("从文件加载了 " + loadedAccounts.size() + " 个账户");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("加载账户信息失败: " + e.getMessage());
        }
    }
}

