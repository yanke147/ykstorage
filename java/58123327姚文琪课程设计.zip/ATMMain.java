package atm1;

import atm1.Account;
import atm1.AccountManager;
import atm1.FileManager;
import atm1.UserInterface;
import java.util.HashMap;
import java.util.Map;
import java.io.*;

//ATMMain 类 - 程序入口
public class ATMMain {
 public static void main(String[] args) {
     // 初始化账户管理器
     AccountManager accountManager = new AccountManager();
     
     // 加载先前保存的账户信息（如果有）
     FileManager.loadAccounts(accountManager);
     
     // 初始化ATM控制器
     ATMController atmController = new ATMController(accountManager);
     
     // 初始化用户界面
     UserInterface ui = new UserInterface(atmController);
     
     // 启动ATM
     ui.start();
     
     // 保存账户信息到文件
     FileManager.saveAccounts(accountManager);
     
     // 关闭ATM控制器
     atmController.shutdown();
 }
}