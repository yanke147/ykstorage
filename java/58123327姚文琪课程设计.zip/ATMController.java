package atm1;

import java.util.Timer;
import java.util.TimerTask;

public class ATMController {
    private AccountManager accountManager;
    private Account currentUser;
    private Timer interestTimer;
    
    public ATMController(AccountManager accountManager) {
        this.accountManager = accountManager;
        this.currentUser = null;
        this.interestTimer = new Timer();
        
        // 设置每10秒计算一次利息的定时任务
        interestTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                calculateInterestForAllAccounts();
            }
        }, 0, 10000);  // 初始延迟0秒，之后每10秒执行一次
    }
    
    // 计算所有账户利息
    public void calculateInterestForAllAccounts() {
        for (Account account : accountManager.getAllAccounts().values()) {
            long currentTime = System.currentTimeMillis();
            long elapsedTime = currentTime - account.getLastInterestUpdate();
            
            if (elapsedTime >= 10000) {  // 只有当超过10秒时才计算利息
                double interestRate = 0.05;  // 5%的利率
                double principal = account.getBalance();  // 本金
                double time = elapsedTime / 10000.0;  // 时间（以10秒为单位）
                double interest = principal * interestRate * time;  // 简单利息计算
                account.setAccumulatedInterest(account.getAccumulatedInterest() + interest);
                account.setLastInterestUpdate(currentTime);  // 更新最后计算利息的时间
            }
        }
    }
    
    // 登录功能
    public boolean login(String username, String password) {
        Account account = accountManager.validateLogin(username, password);
        if (account != null) {
            this.currentUser = account;
            return true;
        } else {
            return false;
        }
    }
    
    // 注册功能
    public boolean register(String username, String password) {
        return accountManager.createAccount(username, password);
    }
    
    // 存款功能
    public void deposit(double amount) {
        if (currentUser != null && amount > 0) {
            currentUser.setBalance(currentUser.getBalance() + amount);
            accountManager.updateAccount(currentUser);
            System.out.println("存款成功！当前余额: " + currentUser.getTotalBalance());
        } else {
            System.out.println("存款失败！");
        }
    }
    
    // 取款功能
    public boolean withdraw(double amount) {
        if (currentUser != null && amount > 0 && amount <= currentUser.getBalance()) {
            currentUser.setBalance(currentUser.getBalance() - amount);
            accountManager.updateAccount(currentUser);
            System.out.println("取款成功！当前余额: " + currentUser.getTotalBalance());
            return true;
        } else {
            System.out.println("取款失败！");
            return false;
        }
    }
    
    // 查询余额功能

    public void checkBalance() {
        if (currentUser != null) {
            System.out.println("当前总余额: " + currentUser.getTotalBalance());
        } else {
            System.out.println("请先登录！");
        }
    }
    // 修改密码功能
    public boolean changePassword(String oldPassword, String newPassword) {
        if (currentUser != null) {
            if (currentUser.getPassword().equals(oldPassword)) {
                currentUser.setPassword(newPassword);
                accountManager.updateAccount(currentUser);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    
 // 查询累计利息
    public void queryAccumulatedInterest() {
        if (currentUser != null) {
            calculateInterestForAllAccounts();  // 计算所有账户的利息
            System.out.println("账户: " + currentUser.getUsername() + " 的累计利息: " + currentUser.getAccumulatedInterest());
        } else {
            System.out.println("请先登录！");
        }
    }
    
    // 获取当前登录用户
    public Account getCurrentUser() {
        return currentUser;
    }
    
    // 登出功能
    public void logout() {
        this.currentUser = null;
    }
    
    // 关闭定时器
    public void shutdown() {
        interestTimer.cancel();
    }
}
